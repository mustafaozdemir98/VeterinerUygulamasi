package com.java.project.vetApp2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VetAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
