package com.java.project.vetApp2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VetApp2Application {

	public static void main(String[] args) {
		SpringApplication.run(VetApp2Application.class, args);
	}

}
